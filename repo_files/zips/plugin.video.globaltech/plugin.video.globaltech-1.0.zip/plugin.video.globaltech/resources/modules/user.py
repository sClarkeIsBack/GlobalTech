import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmdsb2JhbHRlY2g=')

name = b.b64decode('R2xvYmFsIFRlY2g=')

host = b.b64decode('aHR0cDovL2dsb2JhbC1zdHJlYW1zLnphcHRvLm9yZw==')

port = b.b64decode('ODAwMA==')